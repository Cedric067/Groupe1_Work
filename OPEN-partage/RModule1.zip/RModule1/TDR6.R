## Date : 10.05.2020
## VP & VT
## Script TDR6

######## EXERCICE  : importez DesIris.txt, testez les scripts et commentez

# Import
iris1 <- read.table("DesIris.txt", header=TRUE, dec=".", sep=" ", stringsAsFactors = TRUE)  
iris1[ ,1]   # sélection d'une colonne par son numéro avec [,n]
iris1[1, ]   # sélection d'une ligne par son numéro avec [n,]
iris1[1, 2]  # sélection d'une case avec [nlig,ncol]
iris1$SepalLength    # poursuivez les commentaires
iris1[c(1, 5, 10), ]
iris1[-(5:30), ]
iris1[ ,1:4]
iris1[c(5, 1, 10) , c(2, 1, 4, 3)]
iris1[iris1$Species=="virginica", ] # sélection conditionnelle
iris1[iris1$SepalLength > 7 , ]
iris1[iris1$SepalLength < 6  &  iris1$Species=="virginica" , ]
iris1[(iris1$SepalLength < 6  &  iris1$Species=="virginica") | iris1$Species=="setosa"  , ]

# Sélection dans un vecteur
iris1$SepalLength[iris1$Species=="virginica"]
iris1[iris1$Species=="virginica", ]$SepalLength

# Calculs sur des sous-ensembles
apply(iris1[,1:4], MARGIN=2, mean)
tapply(iris1$SepalLength, iris1$Species, mean)


######## EXERCICE  : création du vecteur slv pour "sepal length  virginica" et statistiques

# créer slv

# testez et commentez
mean(slv)
var(slv)
sqrt(var(slv))
sd(slv)
min(slv)
max(slv)
range(slv)
sort(slv)
rev(slv)
sum(slv)
cumsum(slv)
median(slv)
quantile(slv,0.25)
quantile(slv)
length(slv)


######## EXERCICE  : création de variables

# le nom des lignes
n <- nrow(iris1)           # nrow() : nombre de lignes
noms <- paste("iris", 1:n) # paste() : coller
head(noms)

# le rapport de forme
rapport <- iris1$PetalLength/iris1$PetalWidth  
head(rapport)

# v?rification des longueurs 
length(noms); length(rapport); nrow(iris1)

# ajout
names(iris1)
iris1$noms <- noms
names(iris1)

iris2 <- data.frame(iris1, rapport)
names(iris2)

autre <- 1:3
iris1$num <- autre
iris1$num

# Quelle est l'espèce pour laquelle les pétales ont la forme la plus étroite 


######## EXERCICE  : t3var






