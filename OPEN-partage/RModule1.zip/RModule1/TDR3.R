## Date : 23.11.2023
## VP & VT
## Script TDR2

######## EXERCICE : ligne de code permettant de gérer le répertoire courant
getwd() # pour vérifier quel est le répertoire actuel
