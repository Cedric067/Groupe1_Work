## Date : 10.05.2020
## VP & VT
## Script TDR7



######## EXERCICE  : Importer t3var.txt 



######## EXERCICE  : premier graphique (testez, modifiez, commentez)

## version de base
plot(poi~tai)

## customisation I
colo <- c("goldenrod3", "darkblue")[as.numeric(t3var$sexe)] 
colo[1:10]
sexe[1:10]

pttype <- c(17,16)[as.numeric(t3var$sexe)]             
# des formes de points suivant le sexe
pttype[1:10]

titre <- paste("Poids et taille de", nrow(t3var), "individus")  
titre

plot(poi~tai,                             
     main = titre,                        
     xlab = "Taille", ylab = "Poids",     
     col = colo, pch = pttype, cex = 1.5, 
     xlim=c(145,202), ylim=c(45,88))     

## customisation II (ajout d'�l�ments)


######## EXERCICE  : graphiques multiples (testez, modifiez, commentez)

par(mfrow=c(2, 2),mar=c(4, 4, 2, 1),
    mgp=c(2.5, 0.8, 0.5), las=1,  
    cex.axis=0.6,              
    cex.lab=0.8, font.lab=3,    
    font.main=2)               
plot(tai, poi,main="Plot 1")
plot(tai, main="Plot 2")
plot(poi, main="Plot 3")
plot(poi, tai,main="Plot 4")

######## EXERCICE  : recr�ez le graphique demand�








