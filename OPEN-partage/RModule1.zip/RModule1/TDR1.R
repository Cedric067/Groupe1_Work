## Date : 10.05.2020
## VP & VT
## Script TDR1


###################################################
###  Intro- 1e session  
###################################################
x <- 6*7    # On peut stocker un résultat dans un objet
z <- x+2    # manipuler cet objet
x           # puis afficher les résultats
z

######## EXERCICE : Script à tester et corriger
1+1
3^2
sqrt(16)
sqrt(-2)
log(-4)
exp(2)
cos(3.141593)

######## EXERCICE : utilisez ls() et rm() pour supprimer z puis le recreer
ls()      # l'ensemble des objets créés
rm(z)     # suppression de z
ls()      # vérification (regarder aussi la fenetre Environment)
z <- x+1  # on recrée z
z
z <- x+2  # en cas d'erreur on peut directement ecraser un objet pour le remplacer par un nouveau
z

