#########################################
############ GLOSSAIRE ##################
#########################################

##### Fonction Module 1

ls()     # liste des objets cr?es
rm()     # supprime un objet
sqrt(2)  # racine
lm()     #ajuster un modèle linéaire
2^2      # ^ fonction carrée (exposant)
c(1,2)   #création de vecteur
factor() #création de facteur
class(fac3) #le format de l'objet (numeric, character)
