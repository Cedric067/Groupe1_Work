## Date : 10.05.2020
## VP & VT
## Script TDR2

help(lm) # ouvre la page d'aide de la fonction lm
?lm # idem

apropos("lm") # renvoie toutes les fonctions contenant "lm"
help.search("lm") # pages présentant les fonction en lien avec "lm"
??lm # idem
help.start() # affiche les manuels disponibles (en anglais)

